#ifndef _STRING_H
#define _STRING_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

void*  memset (void* ptr, int value, size_t num);
void*  memcpy (void* dst, const void* src, size_t num);
int    strcmp (const char* s1, const char* s2);
char*  strcpy (char* dst, const char* src);
int    strncmp(const char* s1, const char* s2, size_t n);
char*  strncpy(char* dst, const char* src, size_t n);
size_t strlen (const char* s);
char*  strchr (const char* s, int c);

#ifdef __cplusplus
}
#endif

#endif
