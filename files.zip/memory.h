#ifndef _MEMORY_H
#define _MEMORY_H

#include <stddef.h>
#include <stdint.h>

#define PAGE_SIZE 4096ULL

class MemoryManager {
public:
    MemoryManager() = default;
    MemoryManager(uintptr_t start, size_t size);

    void*  allocate(size_t size);
    void   free(void* p, size_t size);

    size_t get_total_size() const;
    size_t get_free_size()  const;
    size_t get_used_size()  const;

private:
    uint8_t*  bitmap;
    uintptr_t base_addr;
    size_t    total_pages;
    size_t    free_pages;

    void mark_page(size_t page_idx, bool used);
    bool is_page_used(size_t page_idx) const;
};

extern MemoryManager* kernel_mem_manager;
extern MemoryManager* user_mem_manager;

void init_memory_manager(uintptr_t start, size_t size);

// Placement new (no stdlib, must be declared here)
inline void* operator new  (size_t, void* p) noexcept { return p; }
inline void* operator new[](size_t, void* p) noexcept { return p; }

// Global new/delete wired to kernel allocator
void* operator new  (size_t size);
void* operator new[](size_t size);
void  operator delete  (void* p) noexcept;
void  operator delete[](void* p) noexcept;
void  operator delete  (void* p, size_t size) noexcept;
void  operator delete[](void* p, size_t size) noexcept;

#endif
