/*
 * boot.asm — 32-bit multiboot2 entry point + long-mode switch
 * Assembles with: nasm -f elf64 boot.asm -o boot.o
 */

bits 32

; ─── Multiboot2 header ──────────────────────────────────────────────────────
MULTIBOOT2_MAGIC    equ 0xE85250D6
MULTIBOOT2_ARCH     equ 0           ; i386 protected-mode
HEADER_LEN          equ (mb2_header_end - mb2_header_start)
CHECKSUM            equ -(MULTIBOOT2_MAGIC + MULTIBOOT2_ARCH + HEADER_LEN)

section .multiboot2
align 8
mb2_header_start:
    dd MULTIBOOT2_MAGIC
    dd MULTIBOOT2_ARCH
    dd HEADER_LEN
    dd CHECKSUM

    ; ── end tag ──
    align 8
    dw 0        ; type  = end
    dw 0        ; flags = 0
    dd 8        ; size  = 8
mb2_header_end:

; ─── Entry point (32-bit protected mode) ────────────────────────────────────
section .text

global _start
_start:
    ; Save multiboot2 registers
    mov  [mb2_magic], eax
    mov  [mb2_addr],  ebx

    cli

    ; Set up a small 32-bit stack for the transition code
    mov  esp, stack32_top

    ; Detect & enable PAE, LONG MODE, then jump to 64-bit world
    call check_cpuid
    call check_longmode
    call setup_paging
    call enter_longmode

    ; Should never reach here
    hlt

; ─── CPUID availability check ───────────────────────────────────────────────
check_cpuid:
    pushfd
    pop  eax
    mov  ecx, eax
    xor  eax, (1 << 21)
    push eax
    popfd
    pushfd
    pop  eax
    push ecx
    popfd
    cmp  eax, ecx
    je   .no_cpuid
    ret
.no_cpuid:
    mov  al, 'C'
    call early_putchar
    hlt

; ─── Long-mode check ────────────────────────────────────────────────────────
check_longmode:
    mov  eax, 0x80000000
    cpuid
    cmp  eax, 0x80000001
    jb   .no_longmode
    mov  eax, 0x80000001
    cpuid
    test edx, (1 << 29)
    jz   .no_longmode
    ret
.no_longmode:
    mov  al, 'L'
    call early_putchar
    hlt

; ─── Identity-map first 2 GB with 2 MB pages ───────────────────────────────
; Page tables are in .bss — already zeroed by GRUB
setup_paging:
    ; PML4[0] → PDPT
    mov  eax, pdpt
    or   eax, 0x03          ; P + RW
    mov  [pml4], eax

    ; PDPT[0] → PDT
    mov  eax, pdt
    or   eax, 0x03
    mov  [pdpt], eax

    ; PDPT[1] → PDT1 (maps 1 GB – 2 GB)
    mov  eax, pdt1
    or   eax, 0x03
    mov  [pdpt + 8], eax

    ; Fill PDT: 512 × 2 MB entries → 0 … 1 GB
    mov  ecx, 0
.loop0:
    mov  eax, ecx
    shl  eax, 21            ; 2 MB steps
    or   eax, 0x83          ; P + RW + PS (2 MB page)
    mov  [pdt + ecx*8], eax
    inc  ecx
    cmp  ecx, 512
    jne  .loop0

    ; Fill PDT1: 512 × 2 MB entries → 1 GB … 2 GB
    mov  ecx, 0
.loop1:
    mov  eax, ecx
    shl  eax, 21
    add  eax, 0x40000000    ; + 1 GB
    or   eax, 0x83
    mov  [pdt1 + ecx*8], eax
    inc  ecx
    cmp  ecx, 512
    jne  .loop1

    ; Load PML4 into CR3
    mov  eax, pml4
    mov  cr3, eax

    ret

; ─── Enable long mode and jump to 64-bit code ───────────────────────────────
enter_longmode:
    ; Enable PAE
    mov  eax, cr4
    or   eax, (1 << 5)     ; PAE
    mov  cr4, eax

    ; Set EFER.LME
    mov  ecx, 0xC0000080
    rdmsr
    or   eax, (1 << 8)     ; LME
    wrmsr

    ; Enable paging (activates long mode)
    mov  eax, cr0
    or   eax, (1 << 31) | (1 << 0)
    mov  cr0, eax

    ; Far jump into 64-bit segment
    jmp  0x08:long_mode_entry

; ─── Simple early text output (32-bit, VGA direct) ──────────────────────────
early_putchar:          ; al = char
    mov  ah, 0x4F       ; white on red
    mov  [0xB8000], ax
    ret

; ─── 64-bit code ─────────────────────────────────────────────────────────────
bits 64

extern kernel_main

long_mode_entry:
    ; Reload all segment registers with null descriptor (flat 64-bit)
    mov  ax, 0x10
    mov  ds, ax
    mov  es, ax
    mov  fs, ax
    mov  gs, ax
    mov  ss, ax

    ; Switch to 64-bit stack
    mov  rsp, stack64_top

    ; Pass multiboot2 info to kernel
    xor  rdi, rdi
    xor  rsi, rsi
    mov  edi, dword [mb2_magic]
    mov  esi, dword [mb2_addr]

    call kernel_main

    cli
.halt:
    hlt
    jmp  .halt

; ─── GDT (minimal: null, code64, data64) ────────────────────────────────────
section .data
align 8
gdt64:
    dq 0x0000000000000000       ; 0x00 — null
    dq 0x00AF9A000000FFFF       ; 0x08 — 64-bit code, DPL0
    dq 0x00AF92000000FFFF       ; 0x10 — 64-bit data, DPL0
gdt64_end:

global gdt64_ptr
gdt64_ptr:
    dw  gdt64_end - gdt64 - 1
    dq  gdt64

; ─── Multiboot2 saved registers ──────────────────────────────────────────────
global mb2_magic
global mb2_addr
mb2_magic: dd 0
mb2_addr:  dd 0

; ─── BSS: stacks + page tables ───────────────────────────────────────────────
section .bss
align 4096

global pml4
global pdpt
global pdt
global pdt1

pml4:  resb 4096
pdpt:  resb 4096
pdt:   resb 4096
pdt1:  resb 4096

; 32-bit bootstrap stack (tiny)
align 16
stack32_bottom: resb 4096
stack32_top:

; 64-bit kernel stack (16 KB)
align 16
stack64_bottom: resb 16384
stack64_top:
