#include "memory.h"
#include "func/writet.h"
#include "func/string.h"

// ─── Global pointers ────────────────────────────────────────────────────────
MemoryManager* kernel_mem_manager = nullptr;
MemoryManager* user_mem_manager   = nullptr;

// ─── Static storage (placement-new targets) ─────────────────────────────────
alignas(MemoryManager) static char km_storage[sizeof(MemoryManager)];
alignas(MemoryManager) static char um_storage[sizeof(MemoryManager)];

// ─── MemoryManager ──────────────────────────────────────────────────────────
MemoryManager::MemoryManager(uintptr_t start, size_t size)
    : base_addr(start), total_pages(size / PAGE_SIZE), free_pages(0)
{
    bitmap = reinterpret_cast<uint8_t*>(start);
    size_t bitmap_bytes = (total_pages + 7) / 8;
    memset(bitmap, 0, bitmap_bytes);

    size_t bitmap_pages = (bitmap_bytes + PAGE_SIZE - 1) / PAGE_SIZE;
    for (size_t i = 0; i < bitmap_pages; i++)
        mark_page(i, true);
    free_pages = total_pages - bitmap_pages;
}

void MemoryManager::mark_page(size_t idx, bool used)
{
    if (used) {
        bitmap[idx / 8] |= static_cast<uint8_t>(1u << (idx % 8));
    } else {
        bitmap[idx / 8] &= static_cast<uint8_t>(~(1u << (idx % 8)));
        free_pages++;
    }
}

bool MemoryManager::is_page_used(size_t idx) const
{
    return bitmap[idx / 8] & static_cast<uint8_t>(1u << (idx % 8));
}

void* MemoryManager::allocate(size_t size)
{
    if (size == 0) return nullptr;
    size_t pages_needed = (size + PAGE_SIZE - 1) / PAGE_SIZE;
    size_t found = 0, start_page = 0;

    for (size_t i = 0; i < total_pages; i++) {
        if (!is_page_used(i)) {
            if (found == 0) start_page = i;
            if (++found == pages_needed) {
                for (size_t j = start_page; j < start_page + pages_needed; j++)
                    mark_page(j, true);
                free_pages -= pages_needed;
                return reinterpret_cast<void*>(base_addr + start_page * PAGE_SIZE);
            }
        } else {
            found = 0;
        }
    }
    print_string_ln("OUT OF MEMORY!");
    return nullptr;
}

void MemoryManager::free(void* p, size_t size)
{
    if (!p) return;
    uintptr_t addr = reinterpret_cast<uintptr_t>(p);
    size_t start_page = (addr - base_addr) / PAGE_SIZE;
    size_t pages      = (size + PAGE_SIZE - 1) / PAGE_SIZE;
    for (size_t i = start_page; i < start_page + pages; i++)
        mark_page(i, false);
}

size_t MemoryManager::get_total_size() const { return total_pages * PAGE_SIZE; }
size_t MemoryManager::get_free_size()  const { return free_pages  * PAGE_SIZE; }
size_t MemoryManager::get_used_size()  const { return get_total_size() - get_free_size(); }

// ─── init helper ────────────────────────────────────────────────────────────
void init_memory_manager(uintptr_t start, size_t size)
{
    kernel_mem_manager = new (km_storage) MemoryManager(start, size / 2);
    user_mem_manager   = new (um_storage) MemoryManager(start + size / 2, size / 2);
}

// ─── Global new / delete ────────────────────────────────────────────────────
void* operator new  (size_t s)       { return kernel_mem_manager->allocate(s); }
void* operator new[](size_t s)       { return kernel_mem_manager->allocate(s); }
void  operator delete  (void*) noexcept {}
void  operator delete[](void*) noexcept {}
void  operator delete  (void* p, size_t s) noexcept { kernel_mem_manager->free(p, s); }
void  operator delete[](void* p, size_t s) noexcept { kernel_mem_manager->free(p, s); }
