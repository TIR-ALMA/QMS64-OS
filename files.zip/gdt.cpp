#include "gdt.h"
#include "writet.h"
#include <stdint.h>

// ─── GDT entry (8 bytes) ────────────────────────────────────────────────────
struct GDTEntry {
    uint16_t limit_low;
    uint16_t base_low;
    uint8_t  base_mid;
    uint8_t  access;
    uint8_t  granularity;   // [7:4] flags | [3:0] limit_high
    uint8_t  base_high;
} __attribute__((packed));

struct GDTPtr {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

// ─── Three entries: null, code64, data64 ────────────────────────────────────
static GDTEntry gdt[3];
static GDTPtr   gdt_ptr;

static void set_entry(int idx, uint32_t base, uint32_t limit,
                      uint8_t access, uint8_t gran)
{
    gdt[idx].base_low   = base & 0xFFFF;
    gdt[idx].base_mid   = (base >> 16) & 0xFF;
    gdt[idx].base_high  = (base >> 24) & 0xFF;
    gdt[idx].limit_low  = limit & 0xFFFF;
    gdt[idx].granularity = ((limit >> 16) & 0x0F) | (gran & 0xF0);
    gdt[idx].access     = access;
}

extern "C" void gdt_flush(GDTPtr* ptr);

__asm__(
    ".global gdt_flush\n"
    "gdt_flush:\n"
    "    lgdt (%rdi)\n"
    "    mov $0x10, %ax\n"
    "    mov %ax, %ds\n"
    "    mov %ax, %es\n"
    "    mov %ax, %fs\n"
    "    mov %ax, %gs\n"
    "    mov %ax, %ss\n"
    // Far return to reload CS
    "    pop %rdi\n"
    "    pushq $0x08\n"
    "    push %rdi\n"
    "    lretq\n"
);

void init_gdt()
{
    print_string_ln("Initializing GDT...");

    // 0: null descriptor
    set_entry(0, 0, 0, 0, 0);

    // 1: kernel code (64-bit), selector 0x08
    //    access  = 0x9A → present, DPL0, code, readable
    //    gran    = 0xA0 → 64-bit flag (L=1), G=1
    set_entry(1, 0, 0xFFFFF, 0x9A, 0xA0);

    // 2: kernel data, selector 0x10
    //    access  = 0x92 → present, DPL0, data, writable
    //    gran    = 0xC0 → DB=1, G=1
    set_entry(2, 0, 0xFFFFF, 0x92, 0xC0);

    gdt_ptr.limit = static_cast<uint16_t>(sizeof(gdt) - 1);
    gdt_ptr.base  = reinterpret_cast<uint64_t>(&gdt);

    gdt_flush(&gdt_ptr);
    print_string_ln("GDT initialized.");
}
