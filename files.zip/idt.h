#ifndef _IDT_H
#define _IDT_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void init_idt();

#ifdef __cplusplus
}
#endif

#endif
