#include "editor.h"
#include "../func/writet.h"
#include "../func/input.h"
#include "../func/string.h"
#include "../func/fs.h"
#include "../memory.h"

#define KEY_ESC 27

extern "C" void run_editor()
{
    clear_screen();
    print_string_ln("--- Text Editor v2.0 (QMS64) ---");
    print_string_ln("Type your text. Press ESC to save and exit.");
    print_string_ln("---------------------------------------");

    char* text_buf = new char[4096];
    int   cursor   = 0;
    char  filename[64];

    print_string("Save as: ");
    int fn = 0;
    while (true) {
        char c = get_char();
        if (c == '\n') { filename[fn] = '\0'; break; }
        if (c == '\b' && fn > 0) {
            fn--;
            move_cursor_back(); print_char(' '); move_cursor_back();
        } else if (c >= ' ' && fn < 63) {
            filename[fn++] = c;
            print_char(c);
        }
    }
    print_char('\n');

    while (true) {
        char key = get_char();
        if (key == KEY_ESC) break;

        if (key == '\b') {
            if (cursor > 0) {
                cursor--;
                move_cursor_back(); print_char(' '); move_cursor_back();
            }
        } else if (key == '\n') {
            if (cursor < 4095) { text_buf[cursor++] = '\n'; print_char('\n'); }
        } else if (key != 0) {
            if (cursor < 4095) { text_buf[cursor++] = key; print_char(key); }
        }
    }

    if (cursor > 0) {
        ram_fs_manager->create_file(filename, 0);
        ram_fs_manager->write_to_file(filename, text_buf, static_cast<size_t>(cursor));
        print_string("\nFile saved: ");
        print_string_ln(filename);
    }

    delete[] text_buf;
    print_string_ln("Exiting editor...");
}
