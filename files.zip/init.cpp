#include "init.h"
#include "func/writet.h"
#include "func/fs.h"
#include "func/gdt.h"
#include "func/idt.h"
#include "func/vga_module.h"
#include "bin/shell.h"
#include "memory.h"

// ─── Multiboot2 structures ───────────────────────────────────────────────────
#define MB2_MAGIC 0x36D76289

struct MB2_Tag {
    uint32_t type;
    uint32_t size;
};

struct MB2_TagMemory {
    uint32_t type;   // 4
    uint32_t size;
    uint32_t mem_lower;   // KB below 1 MB
    uint32_t mem_upper;   // KB above 1 MB
};

// ─── External linker symbol ──────────────────────────────────────────────────
extern "C" char end;

// ─── Static storage for objects placed before heap is ready ─────────────────
alignas(MemoryManager)          static char km_buf[sizeof(MemoryManager)];
alignas(MemoryManager)          static char um_buf[sizeof(MemoryManager)];
alignas(RamFileSystemManager)   static char fs_buf[sizeof(RamFileSystemManager)];

// ─── kernel_main ─────────────────────────────────────────────────────────────
extern "C" void kernel_main(uint32_t mb2_magic, uint32_t mb2_addr)
{
    // 1. VGA + text output
    vgacfg("80x25");
    init_writet();
    clear_screen();
    show_banner();
    print_string_ln("[QMS64-KERNEL][V1.0.0 build-1]");

    // 2. GDT (reload segments in C world)
    init_gdt();

    // 3. Parse multiboot2 memory tag
    size_t total_ram_kb = 0;

    if (mb2_magic == MB2_MAGIC) {
        // Multiboot2 info starts 8 bytes in (total_size + reserved)
        uint8_t* p = reinterpret_cast<uint8_t*>(static_cast<uintptr_t>(mb2_addr)) + 8;
        while (true) {
            MB2_Tag* tag = reinterpret_cast<MB2_Tag*>(p);
            if (tag->type == 0) break;   // end tag
            if (tag->type == 4) {        // basic memory info
                MB2_TagMemory* mt = reinterpret_cast<MB2_TagMemory*>(tag);
                total_ram_kb = mt->mem_lower + mt->mem_upper + 1024;
            }
            uint32_t sz = (tag->size + 7) & ~7u;  // 8-byte aligned
            p += sz;
        }
    }

    if (total_ram_kb == 0) {
        print_string_ln("Warning: No MB2 memory info. Assuming 32 MB.");
        total_ram_kb = 32768;
    }

    print_string("Detected RAM: ");
    print_uint64(total_ram_kb / 1024);
    print_string_ln(" MB");

    // 4. Memory manager
    uintptr_t kernel_end   = reinterpret_cast<uintptr_t>(&end);
    uintptr_t free_start   = (kernel_end + 4095ULL) & ~4095ULL;
    size_t    usable_bytes = (total_ram_kb * 1024ULL) > free_start
                           ? (total_ram_kb * 1024ULL) - free_start
                           : 0;

    kernel_mem_manager = new (km_buf) MemoryManager(free_start,            usable_bytes / 2);
    user_mem_manager   = new (um_buf) MemoryManager(free_start + usable_bytes / 2, usable_bytes / 2);

    print_string("Heap start: "); print_hex(free_start); print_char('\n');

    // 5. IDT
    init_idt();

    // 6. RAM filesystem
    size_t fs_size = 512 * 1024;   // 512 KB
    void*  fs_ptr  = kernel_mem_manager->allocate(fs_size);
    if (fs_ptr) {
        ram_fs_manager = new (fs_buf) RamFileSystemManager(
            reinterpret_cast<char*>(fs_ptr), fs_size);
    } else {
        print_string_ln("ERROR: Could not allocate RAMFS memory!");
    }

    // 7. Shell
    print_string_ln("Starting QMSH...");
    run_shell();

    // Should never return
    while (true) {
        __asm__ volatile("cli; hlt");
    }
}
