#ifndef _MATH_H
#define _MATH_H

#ifdef __cplusplus
extern "C" {
#endif

char* add(const char* a, const char* b);
char* sub(const char* a, const char* b);
char* mul(const char* a, const char* b);
char* div_op(const char* a, const char* b);   /* renamed: 'div' clashes with x86 insn */
int   compare(const char* a, const char* b);

#ifdef __cplusplus
}
#endif

#endif
