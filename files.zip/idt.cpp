#include "idt.h"
#include "writet.h"
#include <stdint.h>

// ─── 64-bit IDT gate (16 bytes) ─────────────────────────────────────────────
struct IDTEntry {
    uint16_t offset_0_15;
    uint16_t selector;
    uint8_t  ist;           // Interrupt Stack Table index (0 = none)
    uint8_t  type_attr;     // 0x8E = present, DPL0, interrupt gate
    uint16_t offset_16_31;
    uint32_t offset_32_63;
    uint32_t reserved;
} __attribute__((packed));

struct IDTPtr {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

// ─── Exception names ─────────────────────────────────────────────────────────
static const char* exception_names[32] = {
    "Division by Zero",         // 0
    "Debug",                    // 1
    "NMI",                      // 2
    "Breakpoint",               // 3
    "Overflow",                 // 4
    "Bound Range Exceeded",     // 5
    "Invalid Opcode",           // 6
    "Device Not Available",     // 7
    "Double Fault",             // 8
    "Coprocessor Seg Overrun",  // 9
    "Invalid TSS",              // 10
    "Segment Not Present",      // 11
    "Stack-Segment Fault",      // 12
    "General Protection Fault", // 13
    "Page Fault",               // 14
    "Reserved",                 // 15
    "x87 FP Exception",         // 16
    "Alignment Check",          // 17
    "Machine Check",            // 18
    "SIMD FP Exception",        // 19
    "Virtualization Exception", // 20
    "Control Protection",       // 21
    "Reserved",                 // 22
    "Reserved",                 // 23
    "Reserved",                 // 24
    "Reserved",                 // 25
    "Reserved",                 // 26
    "Reserved",                 // 27
    "Hypervisor Injection",     // 28
    "VMM Communication",        // 29
    "Security Exception",       // 30
    "Reserved"                  // 31
};

// ─── C handler called from ASM stubs ─────────────────────────────────────────
extern "C" void exception_handler(uint64_t vector, uint64_t error_code,
                                   uint64_t rip, uint64_t cs,
                                   uint64_t rflags, uint64_t rsp)
{
    print_string_ln("\n!!! EXCEPTION !!!");
    if (vector < 32) {
        print_string("Exception: ");
        print_string_ln(exception_names[vector]);
    }
    print_string("Vector:     "); print_int(static_cast<int>(vector));    print_char('\n');
    print_string("Error Code: "); print_int(static_cast<int>(error_code)); print_char('\n');
    print_string("RIP:        "); print_hex(rip);   print_char('\n');
    print_string("CS:         "); print_hex(cs);    print_char('\n');
    print_string("RFLAGS:     "); print_hex(rflags); print_char('\n');
    print_string("RSP:        "); print_hex(rsp);   print_char('\n');
    print_string_ln("System halted.");
    while (true) {
        __asm__ volatile("cli; hlt");
    }
}

// ─── ASM ISR stubs (inline) ──────────────────────────────────────────────────
// Each stub pushes a dummy error code (if none), pushes the vector number,
// then jumps to a common handler that saves registers and calls exception_handler.
__asm__(
    /* Common handler: on entry RSP → [vector, error_code, rip, cs, rflags, rsp] */
    ".global isr_common_stub\n"
    "isr_common_stub:\n"
    "    push %rax\n"
    "    push %rbx\n"
    "    push %rcx\n"
    "    push %rdx\n"
    "    push %rsi\n"
    "    push %rdi\n"
    "    push %rbp\n"
    "    push %r8\n"
    "    push %r9\n"
    "    push %r10\n"
    "    push %r11\n"
    "    push %r12\n"
    "    push %r13\n"
    "    push %r14\n"
    "    push %r15\n"
    /* Arg layout (rdi=vector, rsi=error_code, rdx=rip, rcx=cs, r8=rflags, r9=rsp) */
    /* The stack (after pushes) from top: r15..rax, vector, error_code, rip, cs, rflags, rsp */
    "    mov 15*8(%rsp), %rdi\n"   /* vector      */
    "    mov 16*8(%rsp), %rsi\n"   /* error_code  */
    "    mov 17*8(%rsp), %rdx\n"   /* rip         */
    "    mov 18*8(%rsp), %rcx\n"   /* cs          */
    "    mov 19*8(%rsp), %r8\n"    /* rflags      */
    "    mov 20*8(%rsp), %r9\n"    /* rsp         */
    "    call exception_handler\n"
    "    pop %r15\n"
    "    pop %r14\n"
    "    pop %r13\n"
    "    pop %r12\n"
    "    pop %r11\n"
    "    pop %r10\n"
    "    pop %r9\n"
    "    pop %r8\n"
    "    pop %rbp\n"
    "    pop %rdi\n"
    "    pop %rsi\n"
    "    pop %rdx\n"
    "    pop %rcx\n"
    "    pop %rbx\n"
    "    pop %rax\n"
    /* Pop vector + error_code */
    "    add $16, %rsp\n"
    "    iretq\n"

    /* Macro: no-error-code exceptions */
    ".macro ISR_NO_ERR num\n"
    ".global isr\\num\n"
    "isr\\num:\n"
    "    push $0\n"          /* dummy error code */
    "    push $\\num\n"      /* vector */
    "    jmp isr_common_stub\n"
    ".endm\n"

    /* Macro: exceptions that push an error code */
    ".macro ISR_ERR num\n"
    ".global isr\\num\n"
    "isr\\num:\n"
    "    push $\\num\n"      /* error code already on stack; push vector */
    "    jmp isr_common_stub\n"
    ".endm\n"

    "ISR_NO_ERR 0\n"
    "ISR_NO_ERR 1\n"
    "ISR_NO_ERR 2\n"
    "ISR_NO_ERR 3\n"
    "ISR_NO_ERR 4\n"
    "ISR_NO_ERR 5\n"
    "ISR_NO_ERR 6\n"
    "ISR_NO_ERR 7\n"
    "ISR_ERR    8\n"
    "ISR_NO_ERR 9\n"
    "ISR_ERR   10\n"
    "ISR_ERR   11\n"
    "ISR_ERR   12\n"
    "ISR_ERR   13\n"
    "ISR_ERR   14\n"
    "ISR_NO_ERR 15\n"
    "ISR_NO_ERR 16\n"
    "ISR_ERR   17\n"
    "ISR_NO_ERR 18\n"
    "ISR_NO_ERR 19\n"
    "ISR_NO_ERR 20\n"
    "ISR_ERR   21\n"
    "ISR_NO_ERR 22\n"
    "ISR_NO_ERR 23\n"
    "ISR_NO_ERR 24\n"
    "ISR_NO_ERR 25\n"
    "ISR_NO_ERR 26\n"
    "ISR_NO_ERR 27\n"
    "ISR_NO_ERR 28\n"
    "ISR_NO_ERR 29\n"
    "ISR_ERR   30\n"
    "ISR_NO_ERR 31\n"
);

// Forward declarations for stubs
extern "C" void isr0();  extern "C" void isr1();  extern "C" void isr2();
extern "C" void isr3();  extern "C" void isr4();  extern "C" void isr5();
extern "C" void isr6();  extern "C" void isr7();  extern "C" void isr8();
extern "C" void isr9();  extern "C" void isr10(); extern "C" void isr11();
extern "C" void isr12(); extern "C" void isr13(); extern "C" void isr14();
extern "C" void isr15(); extern "C" void isr16(); extern "C" void isr17();
extern "C" void isr18(); extern "C" void isr19(); extern "C" void isr20();
extern "C" void isr21(); extern "C" void isr22(); extern "C" void isr23();
extern "C" void isr24(); extern "C" void isr25(); extern "C" void isr26();
extern "C" void isr27(); extern "C" void isr28(); extern "C" void isr29();
extern "C" void isr30(); extern "C" void isr31();

typedef void (*isr_fn)();
static isr_fn isr_table[32] = {
    isr0,  isr1,  isr2,  isr3,  isr4,  isr5,  isr6,  isr7,
    isr8,  isr9,  isr10, isr11, isr12, isr13, isr14, isr15,
    isr16, isr17, isr18, isr19, isr20, isr21, isr22, isr23,
    isr24, isr25, isr26, isr27, isr28, isr29, isr30, isr31
};

// ─── IDT table ────────────────────────────────────────────────────────────────
static IDTEntry idt[256];
static IDTPtr   idt_ptr;

static void set_gate(int idx, uint64_t handler)
{
    idt[idx].offset_0_15  = handler & 0xFFFF;
    idt[idx].selector     = 0x08;          // kernel code selector
    idt[idx].ist          = 0;
    idt[idx].type_attr    = 0x8E;          // present, DPL0, interrupt gate
    idt[idx].offset_16_31 = (handler >> 16) & 0xFFFF;
    idt[idx].offset_32_63 = (handler >> 32) & 0xFFFFFFFF;
    idt[idx].reserved     = 0;
}

void init_idt()
{
    print_string_ln("Initializing IDT...");

    for (int i = 0; i < 256; i++) {
        idt[i] = {};
    }

    for (int i = 0; i < 32; i++) {
        set_gate(i, reinterpret_cast<uint64_t>(isr_table[i]));
    }

    idt_ptr.limit = static_cast<uint16_t>(sizeof(idt) - 1);
    idt_ptr.base  = reinterpret_cast<uint64_t>(&idt);

    __asm__ volatile("lidt %0" : : "m"(idt_ptr));
    __asm__ volatile("sti");

    print_string_ln("IDT initialized.");
}
