#include "fs.h"
#include "writet.h"
#include "../memory.h"
#include "string.h"

RamFileSystemManager* ram_fs_manager = nullptr;

RamFileSystemManager::RamFileSystemManager(char* start_addr, size_t size)
    : fs_start_address(start_addr), total_fs_size(size)
{
    superblock  = reinterpret_cast<Superblock*>(fs_start_address);
    inode_table = reinterpret_cast<Inode*>(fs_start_address + sizeof(Superblock));
    data_blocks = fs_start_address + sizeof(Superblock) + sizeof(Inode) * RAMFS_INODE_COUNT;

    memset(fs_start_address, 0, sizeof(Superblock) + sizeof(Inode) * RAMFS_INODE_COUNT);

    superblock->total_inodes = RAMFS_INODE_COUNT;
    superblock->free_inodes  = RAMFS_INODE_COUNT;
    superblock->total_blocks = RAMFS_MAX_BLOCKS;
    superblock->free_blocks  = RAMFS_MAX_BLOCKS;

    print_string_ln("[RAMFS] Initialized.");
}

void RamFileSystemManager::create_file(const char* name, int type)
{
    int idx = -1;
    for (int i = 0; i < RAMFS_INODE_COUNT; i++) {
        if (superblock->inode_map[i] == 0) { idx = i; break; }
    }
    if (idx == -1) { print_string_ln("Error: RAMFS full (no inodes)."); return; }

    Inode* node = &inode_table[idx];
    memset(node, 0, sizeof(Inode));
    strncpy(node->name, name, 15);
    node->type = type;
    node->size = 0;

    superblock->inode_map[idx] = 1;
    superblock->free_inodes--;

    print_string("File created: ");
    print_string_ln(name);
}

void RamFileSystemManager::list_files()
{
    print_string_ln("--- RAMFS File List ---");
    int count = 0;
    for (int i = 0; i < RAMFS_INODE_COUNT; i++) {
        if (superblock->inode_map[i] == 1) {
            print_string("- ");
            print_string(inode_table[i].name);
            print_string(" [Size: ");
            print_int(static_cast<int>(inode_table[i].size));
            print_string_ln(" bytes]");
            count++;
        }
    }
    if (count == 0) print_string_ln("(Empty)");
}

size_t RamFileSystemManager::get_file_size(const char* name)
{
    for (int i = 0; i < RAMFS_INODE_COUNT; i++)
        if (superblock->inode_map[i] == 1 && strcmp(inode_table[i].name, name) == 0)
            return inode_table[i].size;
    return 0;
}

char* RamFileSystemManager::read_from_file(const char* name)
{
    int idx = -1;
    for (int i = 0; i < RAMFS_INODE_COUNT; i++)
        if (superblock->inode_map[i] == 1 && strcmp(inode_table[i].name, name) == 0)
            { idx = i; break; }
    if (idx == -1) return nullptr;

    Inode* node = &inode_table[idx];
    char*  buf  = static_cast<char*>(kernel_mem_manager->allocate(node->size + 1));
    if (!buf) return nullptr;

    size_t read = 0;
    for (int b = 0; read < node->size && b < 8; b++) {
        size_t n = node->size - read;
        if (n > RAMFS_BLOCK_SIZE) n = RAMFS_BLOCK_SIZE;
        memcpy(buf + read, data_blocks + node->blocks[b] * RAMFS_BLOCK_SIZE, n);
        read += n;
    }
    buf[node->size] = '\0';
    return buf;
}

void RamFileSystemManager::write_to_file(const char* name, const char* data, size_t size)
{
    int idx = -1;
    for (int i = 0; i < RAMFS_INODE_COUNT; i++)
        if (superblock->inode_map[i] == 1 && strcmp(inode_table[i].name, name) == 0)
            { idx = i; break; }
    if (idx == -1) return;

    Inode* node = &inode_table[idx];
    node->size = size;

    size_t written = 0;
    for (int b = 0; written < size && b < 8; b++) {
        int blk = -1;
        for (int m = 0; m < RAMFS_MAX_BLOCKS; m++)
            if (superblock->block_map[m] == 0) { blk = m; break; }
        if (blk == -1) break;

        superblock->block_map[blk] = 1;
        node->blocks[b] = blk;
        size_t n = size - written;
        if (n > RAMFS_BLOCK_SIZE) n = RAMFS_BLOCK_SIZE;
        memcpy(data_blocks + blk * RAMFS_BLOCK_SIZE, data + written, n);
        written += n;
        superblock->free_blocks--;
    }
}

void RamFileSystemManager::delete_file(const char* name)
{
    int idx = -1;
    for (int i = 0; i < RAMFS_INODE_COUNT; i++)
        if (superblock->inode_map[i] == 1 && strcmp(inode_table[i].name, name) == 0)
            { idx = i; break; }
    if (idx == -1) return;

    Inode* node   = &inode_table[idx];
    int    blocks = static_cast<int>((node->size + RAMFS_BLOCK_SIZE - 1) / RAMFS_BLOCK_SIZE);
    for (int b = 0; b < blocks && b < 8; b++) {
        superblock->block_map[node->blocks[b]] = 0;
        superblock->free_blocks++;
    }
    superblock->inode_map[idx] = 0;
    superblock->free_inodes++;
    print_string("Deleted: ");
    print_string_ln(name);
}
