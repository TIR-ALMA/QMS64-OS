#ifndef _GDT_H
#define _GDT_H

#include <stdint.h>

// ─── GDT selectors ──────────────────────────────────────────────────────────
#define GDT_KERNEL_CODE  0x08
#define GDT_KERNEL_DATA  0x10

#ifdef __cplusplus
extern "C" {
#endif

void init_gdt();

#ifdef __cplusplus
}
#endif

#endif
