#include "math.h"
#include "string.h"
#include "../memory.h"

// ─── Helpers ─────────────────────────────────────────────────────────────────
static bool is_negative(const char* s) { return s[0] == '-'; }

static const char* abs_ptr(const char* s) { return (s[0] == '-') ? s + 1 : s; }

// Compare absolute values of two digit-strings (no sign)
static int cmp_abs(const char* a, const char* b)
{
    size_t la = strlen(a), lb = strlen(b);
    if (la != lb) return (la > lb) ? 1 : -1;
    return strcmp(a, b);
}

// Compare two signed decimal strings
int compare(const char* a, const char* b)
{
    bool na = is_negative(a), nb = is_negative(b);
    if (na != nb) return na ? -1 : 1;
    int c = cmp_abs(abs_ptr(a), abs_ptr(b));
    return na ? -c : c;
}

// Add two non-negative digit-strings; caller frees result
static char* add_pos(const char* a, const char* b)
{
    size_t la = strlen(a), lb = strlen(b);
    size_t len = (la > lb ? la : lb) + 2;
    char* res = new char[len];
    int carry = 0, ri = (int)len - 1;
    res[ri--] = '\0';
    int ia = (int)la - 1, ib = (int)lb - 1;
    while (ia >= 0 || ib >= 0 || carry) {
        int sum = carry;
        if (ia >= 0) sum += a[ia--] - '0';
        if (ib >= 0) sum += b[ib--] - '0';
        res[ri--] = (char)('0' + sum % 10);
        carry = sum / 10;
    }
    // Skip leading zeros
    char* start = res + ri + 1;
    if (*start == '\0') { res[0] = '0'; res[1] = '\0'; delete[] res; char* r = new char[2]; r[0]='0'; r[1]='\0'; return r; }
    char* out = new char[strlen(start) + 1];
    strcpy(out, start);
    delete[] res;
    return out;
}

// Subtract b from a (a >= b, both non-negative)
static char* sub_pos(const char* a, const char* b)
{
    size_t la = strlen(a), lb = strlen(b);
    char* res = new char[la + 1];
    res[la] = '\0';
    int borrow = 0, ia = (int)la - 1, ib = (int)lb - 1;
    for (int ri = (int)la - 1; ri >= 0; ri--, ia--, ib--) {
        int d = (a[ia] - '0') - borrow;
        if (ib >= 0) d -= (b[ib] - '0');
        if (d < 0) { d += 10; borrow = 1; } else borrow = 0;
        res[ri] = (char)('0' + d);
    }
    // Strip leading zeros
    char* p = res;
    while (*p == '0' && *(p + 1)) p++;
    char* out = new char[strlen(p) + 1];
    strcpy(out, p);
    delete[] res;
    return out;
}

// ─── Public API ──────────────────────────────────────────────────────────────
char* add(const char* a, const char* b)
{
    bool na = is_negative(a), nb = is_negative(b);
    const char* aa = abs_ptr(a), *ab = abs_ptr(b);

    if (na == nb) {
        char* r = add_pos(aa, ab);
        if (na && strcmp(r, "0") != 0) {
            char* nr = new char[strlen(r) + 2];
            nr[0] = '-'; strcpy(nr + 1, r); delete[] r; return nr;
        }
        return r;
    }
    // Different signs
    int c = cmp_abs(aa, ab);
    if (c == 0) { char* r = new char[2]; r[0]='0'; r[1]='\0'; return r; }
    const char* big = (c > 0) ? aa : ab;
    const char* sml = (c > 0) ? ab : aa;
    bool neg_result = (c > 0) ? na : nb;
    char* r = sub_pos(big, sml);
    if (neg_result && strcmp(r, "0") != 0) {
        char* nr = new char[strlen(r) + 2];
        nr[0] = '-'; strcpy(nr + 1, r); delete[] r; return nr;
    }
    return r;
}

char* sub(const char* a, const char* b)
{
    // a - b == a + (-b)
    size_t lb = strlen(b);
    char* nb_str = new char[lb + 2];
    if (is_negative(b)) {
        strcpy(nb_str, b + 1);          // double negative → positive
    } else {
        nb_str[0] = '-';
        strcpy(nb_str + 1, b);
    }
    char* r = add(a, nb_str);
    delete[] nb_str;
    return r;
}

char* mul(const char* a, const char* b)
{
    bool neg = is_negative(a) != is_negative(b);
    const char* aa = abs_ptr(a), *ab = abs_ptr(b);
    size_t la = strlen(aa), lb = strlen(ab);
    size_t len = la + lb + 1;

    int* tmp = new int[len]();   // zero-init
    for (size_t i = la; i-- > 0;)
        for (size_t j = lb; j-- > 0;)
            tmp[i + j + 1] += (aa[i] - '0') * (ab[j] - '0');

    for (size_t i = len - 1; i > 0; i--) {
        tmp[i - 1] += tmp[i] / 10;
        tmp[i] %= 10;
    }
    // Build string
    size_t start = 0;
    while (start < len - 1 && tmp[start] == 0) start++;
    char* res = new char[len - start + 2];
    size_t ri = 0;
    if (neg) res[ri++] = '-';
    for (size_t i = start; i < len; i++)
        res[ri++] = (char)('0' + tmp[i]);
    res[ri] = '\0';
    delete[] tmp;
    return res;
}

char* div_op(const char* a, const char* b)
{
    // Guard: division by zero
    const char* bb = abs_ptr(b);
    if (strcmp(bb, "0") == 0) {
        char* r = new char[4]; strcpy(r, "ERR"); return r;
    }

    bool neg = is_negative(a) != is_negative(b);
    const char* aa = abs_ptr(a), *babs = abs_ptr(b);

    if (cmp_abs(aa, babs) < 0) {
        char* r = new char[2]; r[0]='0'; r[1]='\0'; return r;
    }

    size_t la = strlen(aa);
    char* quotient = new char[la + 2];
    int qi = 0;
    char* cur = new char[la + 2];
    cur[0] = '0'; cur[1] = '\0';

    for (size_t i = 0; i < la; i++) {
        // cur = cur * 10 + aa[i]
        size_t lc = strlen(cur);
        char* nc = new char[lc + 2];
        for (size_t k = 0; k < lc; k++) nc[k] = cur[k];
        nc[lc] = aa[i]; nc[lc + 1] = '\0';
        // Strip leading zeros
        char* p = nc;
        while (*p == '0' && *(p + 1)) p++;
        char* trimmed = new char[strlen(p) + 1];
        strcpy(trimmed, p);
        delete[] nc; delete[] cur; cur = trimmed;

        // Find how many times babs fits into cur
        int d = 0;
        while (cmp_abs(cur, babs) >= 0) {
            char* diff = sub_pos(cur, babs);
            delete[] cur; cur = diff;
            d++;
        }
        quotient[qi++] = (char)('0' + d);
    }
    quotient[qi] = '\0';
    delete[] cur;

    // Strip leading zeros from quotient
    char* p = quotient;
    while (*p == '0' && *(p + 1)) p++;

    char* res;
    if (neg && strcmp(p, "0") != 0) {
        res = new char[strlen(p) + 2];
        res[0] = '-'; strcpy(res + 1, p);
    } else {
        res = new char[strlen(p) + 1];
        strcpy(res, p);
    }
    delete[] quotient;
    return res;
}
