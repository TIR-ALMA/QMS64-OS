/* This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0. */
#ifndef _FUNC_WRITET_H
#define _FUNC_WRITET_H

#include <stdint.h>
#include <stdbool.h>

#ifdef __cplusplus
extern "C" {
#endif

void init_writet();
void print_char     (char c);
void print_string   (const char* s);
void print_string_ln(const char* s);
void print_int      (int n);
void print_uint64   (uint64_t n);
void print_hex      (uint64_t n);   /* e.g. 0xDEADBEEF01234567 */
void move_cursor_back();
void clear_screen   ();
void show_banner    ();

#ifdef __cplusplus
}
#endif

#endif
