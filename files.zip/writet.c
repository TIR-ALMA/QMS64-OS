/* This Source Code Form is subject to the terms of the Mozilla Public License, v. 2.0. */
#include "writet.h"
#include "string.h"
#include "vga_module.h"

static uint16_t SCREEN_WIDTH  = 80;
static uint16_t SCREEN_HEIGHT = 25;

static char* video_memory = (char*)0xB8000;

static int cursor_x = 0;
static int cursor_y = 0;

void init_writet()
{
    vga_get_dimensions(&SCREEN_WIDTH, &SCREEN_HEIGHT);
}

static void scroll_screen()
{
    for (int y = 1; y < SCREEN_HEIGHT; y++) {
        for (int x = 0; x < SCREEN_WIDTH; x++) {
            int from = (y * SCREEN_WIDTH + x) * 2;
            int to   = ((y - 1) * SCREEN_WIDTH + x) * 2;
            video_memory[to]     = video_memory[from];
            video_memory[to + 1] = video_memory[from + 1];
        }
    }
    for (int x = 0; x < SCREEN_WIDTH; x++) {
        int off = ((SCREEN_HEIGHT - 1) * SCREEN_WIDTH + x) * 2;
        video_memory[off]     = ' ';
        video_memory[off + 1] = 0x07;
    }
    cursor_y = SCREEN_HEIGHT - 1;
}

void print_char(char c)
{
    if (c == '\n') {
        cursor_x = 0;
        cursor_y++;
    } else {
        int off = (cursor_y * SCREEN_WIDTH + cursor_x) * 2;
        video_memory[off]     = c;
        video_memory[off + 1] = 0x07;
        cursor_x++;
        if (cursor_x >= SCREEN_WIDTH) {
            cursor_x = 0;
            cursor_y++;
        }
    }
    if (cursor_y >= SCREEN_HEIGHT)
        scroll_screen();
}

void print_string(const char* s)
{
    while (*s) print_char(*s++);
}

void print_string_ln(const char* s)
{
    print_string(s);
    print_char('\n');
}

void move_cursor_back()
{
    if (cursor_x > 0) cursor_x--;
}

void clear_screen()
{
    for (int i = 0; i < SCREEN_WIDTH * SCREEN_HEIGHT; i++) {
        video_memory[i * 2]     = ' ';
        video_memory[i * 2 + 1] = 0x07;
    }
    cursor_x = 0;
    cursor_y = 0;
}

void print_int(int n)
{
    if (n == 0) { print_char('0'); return; }
    if (n < 0)  { print_char('-'); n = -n; }
    char buf[12];
    int i = 0;
    while (n) { buf[i++] = (char)((n % 10) + '0'); n /= 10; }
    for (int j = i - 1; j >= 0; j--) print_char(buf[j]);
}

void print_uint64(uint64_t n)
{
    if (n == 0) { print_char('0'); return; }
    char buf[20];
    int i = 0;
    while (n) { buf[i++] = (char)((n % 10) + '0'); n /= 10; }
    for (int j = i - 1; j >= 0; j--) print_char(buf[j]);
}

void print_hex(uint64_t n)
{
    print_string("0x");
    static const char hex[] = "0123456789ABCDEF";
    char buf[16];
    int i = 0;
    if (n == 0) { print_string("0"); return; }
    while (n) { buf[i++] = hex[n & 0xF]; n >>= 4; }
    for (int j = i - 1; j >= 0; j--) print_char(buf[j]);
}

void show_banner()
{
    print_string_ln(" _____ _____ _____ ");
    print_string_ln("|     |     |   __|");
    print_string_ln("|  |  | | | |__   |");
    print_string_ln("|__  _|_|_|_|_____|");
    print_string_ln("   |__|            ");
}
