#include "string.h"

void* memset(void* ptr, int value, size_t num)
{
    unsigned char* p = (unsigned char*)ptr;
    for (size_t i = 0; i < num; i++)
        p[i] = (unsigned char)value;
    return ptr;
}

void* memcpy(void* dst, const void* src, size_t num)
{
    char* d = (char*)dst;
    const char* s = (const char*)src;
    for (size_t i = 0; i < num; i++)
        d[i] = s[i];
    return dst;
}

int strcmp(const char* s1, const char* s2)
{
    while (*s1 && (*s1 == *s2)) { s1++; s2++; }
    return (unsigned char)*s1 - (unsigned char)*s2;
}

char* strcpy(char* dst, const char* src)
{
    char* orig = dst;
    while ((*dst++ = *src++));
    return orig;
}

int strncmp(const char* s1, const char* s2, size_t n)
{
    if (!n) return 0;
    while (--n && *s1 && *s1 == *s2) { s1++; s2++; }
    return (unsigned char)*s1 - (unsigned char)*s2;
}

char* strncpy(char* dst, const char* src, size_t n)
{
    size_t i;
    for (i = 0; i < n && src[i]; i++) dst[i] = src[i];
    for (; i < n; i++) dst[i] = '\0';
    return dst;
}

size_t strlen(const char* s)
{
    size_t len = 0;
    while (s[len]) len++;
    return len;
}

char* strchr(const char* s, int c)
{
    char ch = (char)c;
    while (*s) {
        if (*s == ch) return (char*)s;
        s++;
    }
    return (ch == '\0') ? (char*)s : (char*)0;
}
