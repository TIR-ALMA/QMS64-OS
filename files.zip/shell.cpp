#include "shell.h"
#include "calc.h"
#include "editor.h"
#include "../func/writet.h"
#include "../func/input.h"
#include "../func/string.h"
#include "../func/fs.h"
#include "../memory.h"

#define CMD_BUF 256

void run_shell()
{
    char buf[CMD_BUF];
    int  cur = 0;

    print_string_ln("QMSH v2.0 [64-bit]");

    while (true) {
        print_string("\nQMSH> ");
        cur = 0;

        // Read line
        while (true) {
            char key = get_char();
            if (key == '\n') { buf[cur] = '\0'; break; }
            else if (key == '\b') {
                if (cur > 0) {
                    cur--;
                    move_cursor_back(); print_char(' '); move_cursor_back();
                }
            } else if (key != 0 && cur < CMD_BUF - 1) {
                buf[cur++] = key; print_char(key);
            }
        }
        print_char('\n');

        if (strlen(buf) == 0) continue;

        // ── Built-in commands ─────────────────────────────────────────────
        if (strcmp(buf, "help") == 0) {
            print_string_ln("Available commands:");
            print_string_ln("  ls          - list files");
            print_string_ln("  touch <n>   - create empty file");
            print_string_ln("  wrd <n> <d> - write text to file");
            print_string_ln("  cat <n>     - read file content");
            print_string_ln("  rm <n>      - delete file");
            print_string_ln("  clear       - clear screen");
            print_string_ln("  mem         - show memory info");
            print_string_ln("  calc        - integer calculator");
            print_string_ln("  edit        - text editor");
            print_string_ln("  arch        - show architecture info");

        } else if (strcmp(buf, "ls") == 0) {
            ram_fs_manager->list_files();

        } else if (strncmp(buf, "touch ", 6) == 0) {
            ram_fs_manager->create_file(buf + 6, 0);

        } else if (strncmp(buf, "wrd ", 4) == 0) {
            char* sp = strchr(buf + 4, ' ');
            if (sp) {
                *sp = '\0';
                ram_fs_manager->write_to_file(buf + 4, sp + 1, strlen(sp + 1));
            } else {
                print_string_ln("Usage: wrd <filename> <data>");
            }

        } else if (strncmp(buf, "cat ", 4) == 0) {
            const char* fn = buf + 4;
            size_t sz = ram_fs_manager->get_file_size(fn);
            if (sz > 0) {
                char* data = ram_fs_manager->read_from_file(fn);
                if (data) {
                    print_string_ln(data);
                    kernel_mem_manager->free(data, sz + 1);
                }
            } else {
                print_string_ln("File empty or not found.");
            }

        } else if (strncmp(buf, "rm ", 3) == 0) {
            ram_fs_manager->delete_file(buf + 3);

        } else if (strcmp(buf, "clear") == 0) {
            clear_screen();

        } else if (strcmp(buf, "mem") == 0) {
            print_string("Total: "); print_uint64(kernel_mem_manager->get_total_size() / 1024); print_string_ln(" KB");
            print_string("Used:  "); print_uint64(kernel_mem_manager->get_used_size()  / 1024); print_string_ln(" KB");
            print_string("Free:  "); print_uint64(kernel_mem_manager->get_free_size()  / 1024); print_string_ln(" KB");

        } else if (strcmp(buf, "arch") == 0) {
            print_string_ln("Architecture: x86-64 (Long Mode)");
            print_string_ln("Paging:       PML4 → PDPT → PDT (2MB pages)");
            print_string_ln("Kernel base:  0x0000000000100000");
            print_string_ln("Register width: 64-bit (RAX, RBX, ...)");

        } else if (strcmp(buf, "calc") == 0) {
            run_calc();

        } else if (strcmp(buf, "edit") == 0) {
            run_editor();

        } else {
            print_string("Command not found: ");
            print_string_ln(buf);
        }
    }
}
