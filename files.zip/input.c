#include "input.h"

static int shift_pressed = 0;
static int ctrl_pressed  = 0;

static unsigned char kbd_us[128] = {
    0, 27, '1','2','3','4','5','6','7','8','9','0','-','=','\b','\t',
    'q','w','e','r','t','y','u','i','o','p','[',']','\n', 0, 'a','s',
    'd','f','g','h','j','k','l',';','\'','`', 0,'\\','z','x','c','v',
    'b','n','m',',','.','/', 0,'*', 0,' ', 0, 0, 0, 0, 0, 0,
     0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
     0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0
};

static unsigned char kbd_us_shift[128] = {
    0, 27, '!','@','#','$','%','^','&','*','(',')',  '_','+','\b','\t',
    'Q','W','E','R','T','Y','U','I','O','P','{','}','\n',  0, 'A','S',
    'D','F','G','H','J','K','L',':','"','~',   0, '|','Z','X','C','V',
    'B','N','M','<','>','?',   0, '*',  0, ' ',  0,  0,  0,  0,  0,  0,
      0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
      0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
      0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,
      0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0,  0
};

static unsigned char get_scancode()
{
    unsigned char sc;
    while (1) {
        __asm__ __volatile__("inb $0x64, %%al" : "=a"(sc));
        if (sc & 0x01) {
            __asm__ __volatile__("inb $0x60, %%al" : "=a"(sc));
            return sc;
        }
    }
}

char get_char()
{
    unsigned char sc = get_scancode();

    if (sc == 0x2A || sc == 0x36) { shift_pressed = 1; return 0; }
    if (sc == 0xAA || sc == 0xB6) { shift_pressed = 0; return 0; }
    if (sc == 0x1D)                { ctrl_pressed  = 1; return 0; }
    if (sc == 0x9D)                { ctrl_pressed  = 0; return 0; }
    if (sc & 0x80)                 { return 0; }

    return shift_pressed ? kbd_us_shift[sc] : kbd_us[sc];
}
